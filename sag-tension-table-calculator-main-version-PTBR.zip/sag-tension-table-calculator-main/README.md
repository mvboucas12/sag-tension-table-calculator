# Sag Tension Table Calculator

Web application for sag and tension calculation in overhead busbars and transmission lines

## Features
- Newton-Raphson Method
- PDF export
- Iterative visualization

## Access
https://mvboucas12.github.io/sag-tension-table-calculator/
